package universo;
import rectas.*;

public class Particula {
    /// Atributos de la clase
    private double masa;
    private double radio; // Creo que es el radio al centro del universo
    private Vector velocidad;
    private Punto posicion;

    public Particula(Punto p, Vector v, double m, double r) {
        posicion = p;
        velocidad = v;
        masa = m;
        radio = r;
    }

    /// @param vz es una fuerza que se aplica a una partícula
     /// @param dt es el tiempo que se le aplica esa fuerza `vz`
    public void mueve(Vector vz, double dt) {
        // Cálculo de la aceleración
        Vector aceleracion = vz.escalar(1/masa);

        // Cálculo de la velocidad final
        Vector velFinal = velocidad.sum(aceleracion.escalar(dt));

        // Cálculo de la poscion final
        Vector desplazamiento = velocidad.escalar(dt);
        double xFinal = posicion.x() + desplazamiento.x();
        double yFinal = posicion.y() + desplazamiento.y();
        Punto posFinal = new Punto(xFinal, yFinal);

        // Actualizo la posición y la velocidad
        this.posicion = posFinal;
        this.velocidad = velFinal;
    }

    public double radio() {
        return radio;
    }

    public Vector fuerzaDesde(Particula part) {
        double G = 6.67E-11;
        double distancia = posicion.distancia(part.posicion());
        //double distancia = this.radio - part.radio();

        Vector vector = new Vector(posicion, part.posicion());
        Vector director = vector.direccion();
        double numeroEscalar = (G * this.masa * part.masa) / Math.pow(distancia,2); // No se si las masas coge las mismas

        Vector fuerza = director.escalar(numeroEscalar);
        return fuerza;
    }

    public Punto posicion() {
        return posicion;
    }

    @Override
    public String toString() {
        return "Particula{" +
                "masa : " + masa +
                ", radio : " + radio +
                ", velocidad : " + velocidad +
                ", posicion : " + posicion +
                '}';
    }
}
