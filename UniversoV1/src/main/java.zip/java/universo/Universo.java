package universo;
import rectas.*;

public record Universo(Particula[] particulas, double radio) {

    public void avanza(double dt){
        Vector[] vectorFuerza = new Vector[particulas.length];
        // Inicializo el array de vectores
        for (int i = 0; i < particulas.length; i++) {
            vectorFuerza[i] = new Vector(0, 0);
        }

        for (int i = 0; i < particulas.length; i++) {
            for (int j = 0; j < particulas.length; j++) {
                if (i != j) {
                    vectorFuerza[i] = vectorFuerza[i].sum(particulas[i].fuerzaDesde(particulas[j]));
                }
            }
            // Cuando ya he calculado la fuerza que se ejerce en la partícula 'i' por todas
            // las demás partículas, ahora si que puedo moverla, teniendo en cuenta
            // esa suma de fuerzas y el tiempo que la quiero mover dt
            particulas[i].mueve(vectorFuerza[i],dt);
        }
    }
}
